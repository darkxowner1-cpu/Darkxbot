<h1 align="center"> 𝐒𝐏𝐀𝐂𝐄 𝐌𝐃 </h1>

<p align="center">
  <a href="https://github.com/Dark-Xploit/SPACE-MD">
    <img alt="SPACE-MD docs" height="350" src="https://files.catbox.moe/ia1mgm.jpg">
  </a>
</p>
    
</a>
</p>
<p align="center">
<a href="https://github.com/Dark-Xploit"><img title="Author" src="https://img.shields.io/badge/SPACE-MD-darkgreen?style=for-the-badge&logo=whatsapp"></a>
<p/>

<p align="center">
    <strong>1. FORK REPOSITORY</strong>
  <br>
    <a href="https://github.com/Dark-Xploit/SPACE-MD/fork" target="_blank">
        <img alt="Fork Repo" src="https://img.shields.io/badge/Fork%20Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkblue&color=darkblue"/>
    </a>
</p>

<p align="center">
    <strong>2. GET SESSION ID</strong>
    <br>
    <a href="https://www.cypherx.space/" target="_blank">
        <img alt="WEBSITE" src="https://img.shields.io/badge/Pair-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkred&color=darkred"/>
    </a>
</p>

<p align="center">
    <strong>3. DEPLOY TO HEROKU</strong>
    <br>
    <a href="https://dashboard.heroku.com/new?template=https://github.com/Dark-Xploit/SPACE-MD" target="_blank">
        <img alt="Deploy to heroku" src="https://img.shields.io/badge/Deploy-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=purple&color=purple"/>
    </a>
</p>

<p align="center">
    <strong>4. DOWNLOAD BOT ZIP</strong>
    <br>
    <a href="https://codeload.github.com/Dark-Xploit/SPACE-MD/zip/refs/heads/main" target="_blank">
        <img alt="Download zip" src="https://img.shields.io/badge/Download-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkorange&color=darkorange"/>
    </a>
</p>
